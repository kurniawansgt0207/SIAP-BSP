/*
 Navicat Premium Data Transfer

 Source Server         : Local
 Source Server Type    : SQL Server
 Source Server Version : 14001000
 Source Host           : DESKTOP-G7S7R4T\SIGITKURNIAWAN:1433
 Source Catalog        : kemsos
 Source Schema         : dbo

 Target Server Type    : SQL Server
 Target Server Version : 14001000
 File Encoding         : 65001

 Date: 02/10/2020 10:34:48
*/


-- ----------------------------
-- Table structure for siap_users
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[dbo].[siap_users]') AND type IN ('U'))
	DROP TABLE [dbo].[siap_users]
GO

CREATE TABLE [dbo].[siap_users] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [fullname] varchar(100) COLLATE Latin1_General_CI_AS  NULL,
  [username] varchar(100) COLLATE Latin1_General_CI_AS  NULL,
  [password] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [aktif] int  NULL,
  [provinsi] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [kabupaten] varchar(255) COLLATE Latin1_General_CI_AS  NULL
)
GO

ALTER TABLE [dbo].[siap_users] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of siap_users
-- ----------------------------
SET IDENTITY_INSERT [dbo].[siap_users] ON
GO

INSERT INTO [dbo].[siap_users] ([id], [fullname], [username], [password], [aktif], [provinsi], [kabupaten]) VALUES (N'1', N'Administrator', N'admin', N'12345678', N'1', NULL, NULL)
GO

INSERT INTO [dbo].[siap_users] ([id], [fullname], [username], [password], [aktif], [provinsi], [kabupaten]) VALUES (N'2', N'Admin PFM', N'pfm', N'1', N'1', NULL, NULL)
GO

INSERT INTO [dbo].[siap_users] ([id], [fullname], [username], [password], [aktif], [provinsi], [kabupaten]) VALUES (N'3', N'Korda Deli Serdang', N'korda_deliserdang', N'1', N'1', N'SUMATERA UTARA', N'DELI SERDANG')
GO

INSERT INTO [dbo].[siap_users] ([id], [fullname], [username], [password], [aktif], [provinsi], [kabupaten]) VALUES (N'4', N'Dinas Sosial Sumut', N'dinsos_sumut', N'1', N'1', N'SUMATERA UTARA', NULL)
GO

INSERT INTO [dbo].[siap_users] ([id], [fullname], [username], [password], [aktif], [provinsi], [kabupaten]) VALUES (N'5', N'Provinsi Sumut', N'prov_sumut', N'1', N'1', N'SUMATERA UTARA', NULL)
GO

INSERT INTO [dbo].[siap_users] ([id], [fullname], [username], [password], [aktif], [provinsi], [kabupaten]) VALUES (N'6', N'Provinsi Jabar', N'prov_jabar', N'1', N'1', N'JAWA BARAT', NULL)
GO

INSERT INTO [dbo].[siap_users] ([id], [fullname], [username], [password], [aktif], [provinsi], [kabupaten]) VALUES (N'7', N'Korda Tasikmalaya', N'korda_tasik', N'1', N'1', N'JAWA BARAT', N'TASIKMALAYA')
GO

INSERT INTO [dbo].[siap_users] ([id], [fullname], [username], [password], [aktif], [provinsi], [kabupaten]) VALUES (N'8', N'Dinas Sosial Jabar', N'dinsos_jabar', N'1', N'1', N'JAWA BARAT', NULL)
GO

SET IDENTITY_INSERT [dbo].[siap_users] OFF
GO


-- ----------------------------
-- Auto increment value for siap_users
-- ----------------------------
DBCC CHECKIDENT ('[dbo].[siap_users]', RESEED, 8)
GO


-- ----------------------------
-- Primary Key structure for table siap_users
-- ----------------------------
ALTER TABLE [dbo].[siap_users] ADD CONSTRAINT [PK__users__3213E83FECF77BED] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  
ON [PRIMARY]
GO

