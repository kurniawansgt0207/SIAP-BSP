/*
 Navicat Premium Data Transfer

 Source Server         : Local
 Source Server Type    : SQL Server
 Source Server Version : 14001000
 Source Host           : DESKTOP-G7S7R4T\SIGITKURNIAWAN:1433
 Source Catalog        : kemsos
 Source Schema         : dbo

 Target Server Type    : SQL Server
 Target Server Version : 14001000
 File Encoding         : 65001

 Date: 02/10/2020 10:33:48
*/


-- ----------------------------
-- Table structure for siap_m_module
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[dbo].[siap_m_module]') AND type IN ('U'))
	DROP TABLE [dbo].[siap_m_module]
GO

CREATE TABLE [dbo].[siap_m_module] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [module_name] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [module_desc] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [module_title] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [is_parent] int  NULL,
  [parent_id] int  NULL,
  [class_icon] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [module_group] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [module_url] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [visual_order] int  NULL
)
GO

ALTER TABLE [dbo].[siap_m_module] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of siap_m_module
-- ----------------------------
SET IDENTITY_INSERT [dbo].[siap_m_module] ON
GO

INSERT INTO [dbo].[siap_m_module] ([id], [module_name], [module_desc], [module_title], [is_parent], [parent_id], [class_icon], [module_group], [module_url], [visual_order]) VALUES (N'1', N'dashboard', N'Dashboard Pengguna', N'Dashboard', N'1', N'0', N'fa-tachometer-alt', N'', N'dashboard', N'1')
GO

INSERT INTO [dbo].[siap_m_module] ([id], [module_name], [module_desc], [module_title], [is_parent], [parent_id], [class_icon], [module_group], [module_url], [visual_order]) VALUES (N'2', N'data_ganda', N'Filter Data Ganda', N'Data Ganda', N'1', N'0', N'fa-folder', N'Transaksi', N'#', N'2')
GO

INSERT INTO [dbo].[siap_m_module] ([id], [module_name], [module_desc], [module_title], [is_parent], [parent_id], [class_icon], [module_group], [module_url], [visual_order]) VALUES (N'3', N'pengesahan', N'Pengesahan Perbaikan Data Ganda', N'Pengesahan', N'1', N'0', N'fa-file', N'Transaksi', N'#', N'3')
GO

INSERT INTO [dbo].[siap_m_module] ([id], [module_name], [module_desc], [module_title], [is_parent], [parent_id], [class_icon], [module_group], [module_url], [visual_order]) VALUES (N'4', N'filter_data_ganda_keluarga', N'Perbaikan Data Ganda Keluarga', N'Ganda Keluarga', N'0', N'2', NULL, N'Transaksi', N'transaksi', N'1')
GO

INSERT INTO [dbo].[siap_m_module] ([id], [module_name], [module_desc], [module_title], [is_parent], [parent_id], [class_icon], [module_group], [module_url], [visual_order]) VALUES (N'5', N'filter_data_ganda_identik', N'Perbaikan Data Ganda Identik', N'Ganda Identik', N'0', N'2', NULL, N'Transaksi', N'transaksi/ganda_identik', N'2')
GO

INSERT INTO [dbo].[siap_m_module] ([id], [module_name], [module_desc], [module_title], [is_parent], [parent_id], [class_icon], [module_group], [module_url], [visual_order]) VALUES (N'6', N'registrasi_pengesahan', N'Registrasi Pengesahan Perbaikan Data Ganda', N'Registrasi Pengesahan', N'0', N'3', NULL, N'Transaksi', N'transaksi/buat_pengesahan', N'1')
GO

INSERT INTO [dbo].[siap_m_module] ([id], [module_name], [module_desc], [module_title], [is_parent], [parent_id], [class_icon], [module_group], [module_url], [visual_order]) VALUES (N'7', N'upload_pengesahan', N'Upload Registrasi Pengesahan', N'Upload Pengesahan', N'0', N'3', NULL, N'Transaksi', N'transaksi/upload_pengesahan', N'2')
GO

INSERT INTO [dbo].[siap_m_module] ([id], [module_name], [module_desc], [module_title], [is_parent], [parent_id], [class_icon], [module_group], [module_url], [visual_order]) VALUES (N'8', N'status_pengesahan', N'Status Upload Pengesahan Data Perbaikan', N'Status Pengesahan', N'0', N'3', NULL, N'Transaksi', N'transaksi/status_pengesahan', N'3')
GO

INSERT INTO [dbo].[siap_m_module] ([id], [module_name], [module_desc], [module_title], [is_parent], [parent_id], [class_icon], [module_group], [module_url], [visual_order]) VALUES (N'9', N'rpt_data_ganda', N'Laporan-laporan Data Ganda', N'Data Ganda', N'1', N'0', N'fa-bars', N'Laporan', N'#', NULL)
GO

INSERT INTO [dbo].[siap_m_module] ([id], [module_name], [module_desc], [module_title], [is_parent], [parent_id], [class_icon], [module_group], [module_url], [visual_order]) VALUES (N'10', N'rpt_ganda_keluarga', N'Laporan Data Ganda Keluarga', N'Ganda Keluarga', N'1', N'9', N'fa-bars', N'Laporan', N'#', N'1')
GO

INSERT INTO [dbo].[siap_m_module] ([id], [module_name], [module_desc], [module_title], [is_parent], [parent_id], [class_icon], [module_group], [module_url], [visual_order]) VALUES (N'11', N'rpt_ganda_identik', N'Laporan Data Ganda Identik', N'Ganda Identik', N'1', N'9', N'fa-bars', N'Laporan', N'#', N'2')
GO

INSERT INTO [dbo].[siap_m_module] ([id], [module_name], [module_desc], [module_title], [is_parent], [parent_id], [class_icon], [module_group], [module_url], [visual_order]) VALUES (N'12', N'rpt_summary_ganda_keluarga', N'Laporan Rekap Ganda Keluarga', N'Rekap', N'0', N'10', NULL, N'Laporan', N'laporan/summary_keluarga', N'1')
GO

INSERT INTO [dbo].[siap_m_module] ([id], [module_name], [module_desc], [module_title], [is_parent], [parent_id], [class_icon], [module_group], [module_url], [visual_order]) VALUES (N'13', N'rpt_detail_ganda_keluarga', N'Laporan Detail Ganda Keluarga', N'Detail', N'0', N'10', NULL, N'Laporan', N'laporan/detail_keluarga', N'2')
GO

INSERT INTO [dbo].[siap_m_module] ([id], [module_name], [module_desc], [module_title], [is_parent], [parent_id], [class_icon], [module_group], [module_url], [visual_order]) VALUES (N'14', N'rpt_summary_ganda_identik', N'Laporan Rekap Ganda Identik', N'Rekap', N'0', N'11', NULL, N'Laporan', N'laporan/summary_identik', N'1')
GO

INSERT INTO [dbo].[siap_m_module] ([id], [module_name], [module_desc], [module_title], [is_parent], [parent_id], [class_icon], [module_group], [module_url], [visual_order]) VALUES (N'15', N'rpt_detail_ganda_identik', N'Laporan Detail Ganda Identik', N'Detail', N'0', N'11', NULL, N'Laporan', N'laporan/detail_identik', N'2')
GO

SET IDENTITY_INSERT [dbo].[siap_m_module] OFF
GO


-- ----------------------------
-- Auto increment value for siap_m_module
-- ----------------------------
DBCC CHECKIDENT ('[dbo].[siap_m_module]', RESEED, 15)
GO


-- ----------------------------
-- Indexes structure for table siap_m_module
-- ----------------------------
CREATE NONCLUSTERED INDEX [groupmdlIDX]
ON [dbo].[siap_m_module] (
  [module_group] ASC
)
GO

CREATE NONCLUSTERED INDEX [parentIDX]
ON [dbo].[siap_m_module] (
  [parent_id] ASC
)
GO

CREATE NONCLUSTERED INDEX [isparentIDX]
ON [dbo].[siap_m_module] (
  [is_parent] ASC
)
GO


-- ----------------------------
-- Primary Key structure for table siap_m_module
-- ----------------------------
ALTER TABLE [dbo].[siap_m_module] ADD CONSTRAINT [PK__m_module__3213E83F18E69FF1] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  
ON [PRIMARY]
GO

