/*
 Navicat Premium Data Transfer

 Source Server         : Local
 Source Server Type    : SQL Server
 Source Server Version : 14001000
 Source Host           : DESKTOP-G7S7R4T\SIGITKURNIAWAN:1433
 Source Catalog        : kemsos
 Source Schema         : dbo

 Target Server Type    : SQL Server
 Target Server Version : 14001000
 File Encoding         : 65001

 Date: 24/09/2020 07:59:44
*/


-- ----------------------------
-- Table structure for upload_data_ganda_revisi
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[dbo].[upload_data_ganda_revisi]') AND type IN ('U'))
	DROP TABLE [dbo].[upload_data_ganda_revisi]
GO

CREATE TABLE [dbo].[upload_data_ganda_revisi] (
  [ID] int  IDENTITY(1,1) NOT NULL,
  [TGL_UPLOAD] datetime  NULL,
  [PROVINSI] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [KABUPATEN] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [FILE_UPLOAD] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [USER_UPLOAD] varchar(255) COLLATE Latin1_General_CI_AS  NULL
)
GO

ALTER TABLE [dbo].[upload_data_ganda_revisi] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Auto increment value for upload_data_ganda_revisi
-- ----------------------------
DBCC CHECKIDENT ('[dbo].[upload_data_ganda_revisi]', RESEED, 1)
GO


-- ----------------------------
-- Primary Key structure for table upload_data_ganda_revisi
-- ----------------------------
ALTER TABLE [dbo].[upload_data_ganda_revisi] ADD CONSTRAINT [PK__upload_d__3214EC27B8C76735] PRIMARY KEY CLUSTERED ([ID])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  
ON [PRIMARY]
GO

