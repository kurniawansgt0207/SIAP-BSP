/*
 Navicat Premium Data Transfer

 Source Server         : Local
 Source Server Type    : SQL Server
 Source Server Version : 14001000
 Source Host           : DESKTOP-G7S7R4T\SIGITKURNIAWAN:1433
 Source Catalog        : kemsos
 Source Schema         : dbo

 Target Server Type    : SQL Server
 Target Server Version : 14001000
 File Encoding         : 65001

 Date: 24/09/2020 07:54:10
*/


-- ----------------------------
-- Table structure for data_ganda
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[dbo].[data_ganda]') AND type IN ('U'))
	DROP TABLE [dbo].[data_ganda]
GO

CREATE TABLE [dbo].[data_ganda] (
  [NAMA_PENERIMA] nvarchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [NOMOR_KARTU] nvarchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [NIK_KTP] nvarchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [KODE_WILAYAH] nvarchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [FLAG] nvarchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [STATUS_REKENING] nvarchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [STATUS_KARTU] nvarchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [STATUS_NIK] nvarchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [NAMA_REKENING_DI_BANK] nvarchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [NO_KARTU_DI_BANK] nvarchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [NO_NIK] nvarchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [WIL] nvarchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [BANK] nvarchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [ID_PENGURUS] nvarchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [NMPROP] nvarchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [NMKAB] nvarchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [NMKEC] nvarchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [NMKEL] nvarchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [ALAMAT] nvarchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [KET] nvarchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [KETDATA] nvarchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [NOPESERTAPKH] nvarchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [KDPROP] nvarchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [IDBDT] nvarchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [IDARTBDT] nvarchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [IDPENGURUS] nvarchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [NAMA_DTKS] nvarchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [NIK_DTKS] nvarchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [NOKK_DTKS] nvarchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [TGLLAHIR_DTKS] nvarchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [NAMAIBU_DTKS] nvarchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [FLAGNIK] nvarchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [PERCENTILE] nvarchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [STADATA] nvarchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [STAGANDA] nvarchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [IDKELUARGA] nvarchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [KET_TAMBAHAN] nvarchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [NOREKENING] nvarchar(255) COLLATE Latin1_General_CI_AS  NULL
)
GO

ALTER TABLE [dbo].[data_ganda] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Indexes structure for table data_ganda
-- ----------------------------
CREATE NONCLUSTERED INDEX [propIDX]
ON [dbo].[data_ganda] (
  [NMPROP] ASC
)
GO

CREATE NONCLUSTERED INDEX [kabIDX]
ON [dbo].[data_ganda] (
  [NMKAB] ASC
)
GO

CREATE NONCLUSTERED INDEX [kecIDX]
ON [dbo].[data_ganda] (
  [NMKEC] ASC
)
GO

CREATE NONCLUSTERED INDEX [kelIDX]
ON [dbo].[data_ganda] (
  [NMKEL] ASC
)
GO

CREATE NONCLUSTERED INDEX [statusIDX]
ON [dbo].[data_ganda] (
  [KET_TAMBAHAN] ASC
)
GO

CREATE NONCLUSTERED INDEX [idpenerimaIDX]
ON [dbo].[data_ganda] (
  [IDARTBDT] ASC
)
GO

