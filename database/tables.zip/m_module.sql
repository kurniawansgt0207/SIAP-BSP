/*
 Navicat Premium Data Transfer

 Source Server         : Local
 Source Server Type    : SQL Server
 Source Server Version : 14001000
 Source Host           : DESKTOP-G7S7R4T\SIGITKURNIAWAN:1433
 Source Catalog        : kemsos
 Source Schema         : dbo

 Target Server Type    : SQL Server
 Target Server Version : 14001000
 File Encoding         : 65001

 Date: 24/09/2020 07:58:45
*/


-- ----------------------------
-- Table structure for m_module
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[dbo].[m_module]') AND type IN ('U'))
	DROP TABLE [dbo].[m_module]
GO

CREATE TABLE [dbo].[m_module] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [module_name] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [module_desc] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [module_title] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [is_parent] int  NULL,
  [parent_id] int  NULL,
  [class_icon] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [module_group] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [module_url] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [visual_order] int  NULL
)
GO

ALTER TABLE [dbo].[m_module] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of m_module
-- ----------------------------
SET IDENTITY_INSERT [dbo].[m_module] ON
GO

INSERT INTO [dbo].[m_module] ([id], [module_name], [module_desc], [module_title], [is_parent], [parent_id], [class_icon], [module_group], [module_url], [visual_order]) VALUES (N'1', N'dashboard', N'Dashboard Pengguna', N'Dashboard', N'1', N'0', N'fa-tachometer-alt', N'', N'dashboard', N'1')
GO

INSERT INTO [dbo].[m_module] ([id], [module_name], [module_desc], [module_title], [is_parent], [parent_id], [class_icon], [module_group], [module_url], [visual_order]) VALUES (N'2', N'data_ganda', N'Filter Data Ganda', N'Data Ganda', N'1', N'0', N'fa-folder', N'Transaksi', N'#', N'2')
GO

INSERT INTO [dbo].[m_module] ([id], [module_name], [module_desc], [module_title], [is_parent], [parent_id], [class_icon], [module_group], [module_url], [visual_order]) VALUES (N'3', N'surat_permohonan', N'Surat Permohonan', N'Surat Permohonan', N'1', N'0', N'fa-file', N'Transaksi', N'#', N'3')
GO

INSERT INTO [dbo].[m_module] ([id], [module_name], [module_desc], [module_title], [is_parent], [parent_id], [class_icon], [module_group], [module_url], [visual_order]) VALUES (N'4', N'unduh_template', N'Unduh Template Surat Permohonan', N'Download Template', N'0', N'3', NULL, N'Transaksi', N'transaksi/download_surat', N'1')
GO

INSERT INTO [dbo].[m_module] ([id], [module_name], [module_desc], [module_title], [is_parent], [parent_id], [class_icon], [module_group], [module_url], [visual_order]) VALUES (N'5', N'unggah_permohonan', N'Unggah Surat Permohonan', N'Upload Permohonan', N'0', N'3', NULL, N'Transaksi', N'transaksi/upload_surat', N'2')
GO

INSERT INTO [dbo].[m_module] ([id], [module_name], [module_desc], [module_title], [is_parent], [parent_id], [class_icon], [module_group], [module_url], [visual_order]) VALUES (N'6', N'cek_permohonan', N'Cek Surat Permohonan', N'Cek Permohonan', N'0', N'3', NULL, N'Transaksi', N'transaksi/daftar_surat', N'3')
GO

INSERT INTO [dbo].[m_module] ([id], [module_name], [module_desc], [module_title], [is_parent], [parent_id], [class_icon], [module_group], [module_url], [visual_order]) VALUES (N'7', N'rpt_data_ganda', N'Laporan Data Ganda', N'Data Ganda Penduduk', N'1', N'0', N'fa-bars', N'Laporan', N'#', N'4')
GO

INSERT INTO [dbo].[m_module] ([id], [module_name], [module_desc], [module_title], [is_parent], [parent_id], [class_icon], [module_group], [module_url], [visual_order]) VALUES (N'8', N'rpt_summary_data_ganda', N'Summary Laporan Data Ganda', N'Summary', N'0', N'7', NULL, N'', N'laporan/summary_data', N'1')
GO

INSERT INTO [dbo].[m_module] ([id], [module_name], [module_desc], [module_title], [is_parent], [parent_id], [class_icon], [module_group], [module_url], [visual_order]) VALUES (N'9', N'rpt_detail_data_ganda', N'Detail Laporan Data Ganda', N'Detail', N'0', N'7', NULL, N'', N'laporan', N'2')
GO

INSERT INTO [dbo].[m_module] ([id], [module_name], [module_desc], [module_title], [is_parent], [parent_id], [class_icon], [module_group], [module_url], [visual_order]) VALUES (N'10', N'upload_data_perbaikan', N'Upload Data Ganda Perbaikan Status', N'Upload Data Perbaikan', N'0', N'2', NULL, N'Transaksi', N'transaksi/upload_data_revisi', N'3')
GO

INSERT INTO [dbo].[m_module] ([id], [module_name], [module_desc], [module_title], [is_parent], [parent_id], [class_icon], [module_group], [module_url], [visual_order]) VALUES (N'11', N'filter_data_ganda', N'Filter Data Ganda Penerima Bantuan', N'Filter Ganda Keluarga', N'0', N'2', NULL, N'Transaksi', N'transaksi', N'1')
GO

INSERT INTO [dbo].[m_module] ([id], [module_name], [module_desc], [module_title], [is_parent], [parent_id], [class_icon], [module_group], [module_url], [visual_order]) VALUES (N'12', N'filter_data_ganda_identik', N'Filter Data Ganda Keluarga Penerima Bantuan', N'Filter Ganda Identik', N'0', N'2', NULL, N'Transaksi', N'transaksi/ganda_identik', N'2')
GO

SET IDENTITY_INSERT [dbo].[m_module] OFF
GO


-- ----------------------------
-- Auto increment value for m_module
-- ----------------------------
DBCC CHECKIDENT ('[dbo].[m_module]', RESEED, 12)
GO


-- ----------------------------
-- Primary Key structure for table m_module
-- ----------------------------
ALTER TABLE [dbo].[m_module] ADD CONSTRAINT [PK__m_module__3213E83F18E69FF1] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  
ON [PRIMARY]
GO

