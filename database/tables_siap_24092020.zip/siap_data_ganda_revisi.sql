/*
 Navicat Premium Data Transfer

 Source Server         : Local
 Source Server Type    : SQL Server
 Source Server Version : 14001000
 Source Host           : DESKTOP-G7S7R4T\SIGITKURNIAWAN:1433
 Source Catalog        : kemsos
 Source Schema         : dbo

 Target Server Type    : SQL Server
 Target Server Version : 14001000
 File Encoding         : 65001

 Date: 25/09/2020 05:54:56
*/


-- ----------------------------
-- Table structure for siap_data_ganda_revisi
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[dbo].[siap_data_ganda_revisi]') AND type IN ('U'))
	DROP TABLE [dbo].[siap_data_ganda_revisi]
GO

CREATE TABLE [dbo].[siap_data_ganda_revisi] (
  [ID] int  IDENTITY(1,1) NOT NULL,
  [ID_UPLOAD] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [NAMA_PENERIMA] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [NOMOR_KARTU] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [NIK_KTP] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [KODE_WILAYAH] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [FLAG] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [STATUS_REKENING] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [STATUS_KARTU] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [STATUS_NIK] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [NAMA_REKENING_DI_BANK] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [NO_KARTU_DI_BANK] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [NO_NIK] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [WIL] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [BANK] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [ID_PENGURUS] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [NMPROP] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [NMKAB] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [NMKEC] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [NMKEL] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [ALAMAT] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [KET] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [KETDATA] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [NOPESERTAPKH] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [KDPROP] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [IDBDT] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [IDARTBDT] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [IDPENGURUS] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [NAMA_DTKS] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [NIK_DTKS] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [NOKK_DTKS] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [TGLLAHIR_DTKS] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [NAMAIBU_DTKS] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [FLAGNIK] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [PERCENTILE] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [STADATA] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [STAGANDA] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [IDKELUARGA] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [KET_TAMBAHAN] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [NOREKENING] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [STATUS_BARU] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [STATUS_DATA] varchar(255) COLLATE Latin1_General_CI_AS  NULL
)
GO

ALTER TABLE [dbo].[siap_data_ganda_revisi] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Auto increment value for siap_data_ganda_revisi
-- ----------------------------
DBCC CHECKIDENT ('[dbo].[siap_data_ganda_revisi]', RESEED, 3445)
GO


-- ----------------------------
-- Primary Key structure for table siap_data_ganda_revisi
-- ----------------------------
ALTER TABLE [dbo].[siap_data_ganda_revisi] ADD CONSTRAINT [PK__data_gan__3214EC27E440CF58] PRIMARY KEY CLUSTERED ([ID])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  
ON [PRIMARY]
GO

