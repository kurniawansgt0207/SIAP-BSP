/*
 Navicat Premium Data Transfer

 Source Server         : Local
 Source Server Type    : SQL Server
 Source Server Version : 14001000
 Source Host           : DESKTOP-G7S7R4T\SIGITKURNIAWAN:1433
 Source Catalog        : kemsos
 Source Schema         : dbo

 Target Server Type    : SQL Server
 Target Server Version : 14001000
 File Encoding         : 65001

 Date: 25/09/2020 05:56:34
*/


-- ----------------------------
-- Table structure for siap_surat_permohonan_data_ganda
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[dbo].[siap_surat_permohonan_data_ganda]') AND type IN ('U'))
	DROP TABLE [dbo].[siap_surat_permohonan_data_ganda]
GO

CREATE TABLE [dbo].[siap_surat_permohonan_data_ganda] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [tgl_permohonan] date  NULL,
  [nm_pemohon] varchar(100) COLLATE Latin1_General_CI_AS  NULL,
  [nm_propinsi] varchar(100) COLLATE Latin1_General_CI_AS  NULL,
  [nm_kabupaten] varchar(100) COLLATE Latin1_General_CI_AS  NULL,
  [nm_surat_permohonan] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [nm_lampiran_dokumen] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [status_permohonan] varchar(50) COLLATE Latin1_General_CI_AS  NULL,
  [nm_pengecek] varchar(100) COLLATE Latin1_General_CI_AS  NULL,
  [alasan_tolak] text COLLATE Latin1_General_CI_AS  NULL,
  [tgl_acc_dinsos] date  NULL,
  [acc_dinsos_by] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [tgl_acc_provinsi] date  NULL,
  [acc_provinsi_by] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [tgl_acc_pfm] date  NULL,
  [acc_pfm_by] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [tgl_update_revisi] date  NULL,
  [update_revisi_by] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [no_registrasi_revisi] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [tgl_rejected] date  NULL
)
GO

ALTER TABLE [dbo].[siap_surat_permohonan_data_ganda] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Auto increment value for siap_surat_permohonan_data_ganda
-- ----------------------------
DBCC CHECKIDENT ('[dbo].[siap_surat_permohonan_data_ganda]', RESEED, 2)
GO


-- ----------------------------
-- Primary Key structure for table siap_surat_permohonan_data_ganda
-- ----------------------------
ALTER TABLE [dbo].[siap_surat_permohonan_data_ganda] ADD CONSTRAINT [PK__surat_pe__3213E83F35EC67E6] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  
ON [PRIMARY]
GO

