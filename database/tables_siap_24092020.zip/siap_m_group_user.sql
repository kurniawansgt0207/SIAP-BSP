/*
 Navicat Premium Data Transfer

 Source Server         : Local
 Source Server Type    : SQL Server
 Source Server Version : 14001000
 Source Host           : DESKTOP-G7S7R4T\SIGITKURNIAWAN:1433
 Source Catalog        : kemsos
 Source Schema         : dbo

 Target Server Type    : SQL Server
 Target Server Version : 14001000
 File Encoding         : 65001

 Date: 25/09/2020 05:55:18
*/


-- ----------------------------
-- Table structure for siap_m_group_user
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[dbo].[siap_m_group_user]') AND type IN ('U'))
	DROP TABLE [dbo].[siap_m_group_user]
GO

CREATE TABLE [dbo].[siap_m_group_user] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [group_user] varchar(50) COLLATE Latin1_General_CI_AS  NULL,
  [group_user_desc] varchar(255) COLLATE Latin1_General_CI_AS  NULL
)
GO

ALTER TABLE [dbo].[siap_m_group_user] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of siap_m_group_user
-- ----------------------------
SET IDENTITY_INSERT [dbo].[siap_m_group_user] ON
GO

INSERT INTO [dbo].[siap_m_group_user] ([id], [group_user], [group_user_desc]) VALUES (N'1', N'Administrator', N'Administrator Sistem')
GO

INSERT INTO [dbo].[siap_m_group_user] ([id], [group_user], [group_user_desc]) VALUES (N'2', N'PFM', N'Pusat')
GO

INSERT INTO [dbo].[siap_m_group_user] ([id], [group_user], [group_user_desc]) VALUES (N'3', N'Provinsi', N'Provinsi')
GO

INSERT INTO [dbo].[siap_m_group_user] ([id], [group_user], [group_user_desc]) VALUES (N'4', N'Dinsos', N'Dinas Sosial Provinsi')
GO

INSERT INTO [dbo].[siap_m_group_user] ([id], [group_user], [group_user_desc]) VALUES (N'5', N'Korda', N'Koordinator Daerah')
GO

SET IDENTITY_INSERT [dbo].[siap_m_group_user] OFF
GO


-- ----------------------------
-- Auto increment value for siap_m_group_user
-- ----------------------------
DBCC CHECKIDENT ('[dbo].[siap_m_group_user]', RESEED, 5)
GO


-- ----------------------------
-- Primary Key structure for table siap_m_group_user
-- ----------------------------
ALTER TABLE [dbo].[siap_m_group_user] ADD CONSTRAINT [PK__m_group___3213E83F7E213853] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  
ON [PRIMARY]
GO

