/*
 Navicat Premium Data Transfer

 Source Server         : Local
 Source Server Type    : SQL Server
 Source Server Version : 14001000
 Source Host           : DESKTOP-G7S7R4T\SIGITKURNIAWAN:1433
 Source Catalog        : kemsos
 Source Schema         : dbo

 Target Server Type    : SQL Server
 Target Server Version : 14001000
 File Encoding         : 65001

 Date: 24/09/2020 08:18:15
*/


-- ----------------------------
-- Table structure for siap_m_wilayah
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[dbo].[siap_m_wilayah]') AND type IN ('U'))
	DROP TABLE [dbo].[siap_m_wilayah]
GO

CREATE TABLE [dbo].[siap_m_wilayah] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [nm_wilayah] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [is_parent] int  NULL,
  [parentid] int  NULL
)
GO

ALTER TABLE [dbo].[siap_m_wilayah] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of siap_m_wilayah
-- ----------------------------
SET IDENTITY_INSERT [dbo].[siap_m_wilayah] ON
GO

INSERT INTO [dbo].[siap_m_wilayah] ([id], [nm_wilayah], [is_parent], [parentid]) VALUES (N'1', N'Wilayah I', N'1', N'0')
GO

INSERT INTO [dbo].[siap_m_wilayah] ([id], [nm_wilayah], [is_parent], [parentid]) VALUES (N'2', N'Sumatera', N'0', N'1')
GO

INSERT INTO [dbo].[siap_m_wilayah] ([id], [nm_wilayah], [is_parent], [parentid]) VALUES (N'3', N'Jawa Barat', N'0', N'1')
GO

SET IDENTITY_INSERT [dbo].[siap_m_wilayah] OFF
GO


-- ----------------------------
-- Auto increment value for siap_m_wilayah
-- ----------------------------
DBCC CHECKIDENT ('[dbo].[siap_m_wilayah]', RESEED, 3)
GO


-- ----------------------------
-- Primary Key structure for table siap_m_wilayah
-- ----------------------------
ALTER TABLE [dbo].[siap_m_wilayah] ADD CONSTRAINT [PK__m_wilaya__3213E83F6990EB34] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  
ON [PRIMARY]
GO

