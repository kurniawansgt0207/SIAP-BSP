/*
 Navicat Premium Data Transfer

 Source Server         : Local
 Source Server Type    : SQL Server
 Source Server Version : 14001000
 Source Host           : DESKTOP-G7S7R4T\SIGITKURNIAWAN:1433
 Source Catalog        : kemsos
 Source Schema         : dbo

 Target Server Type    : SQL Server
 Target Server Version : 14001000
 File Encoding         : 65001

 Date: 24/09/2020 08:17:10
*/


-- ----------------------------
-- Table structure for siap_m_group_user_detail
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[dbo].[siap_m_group_user_detail]') AND type IN ('U'))
	DROP TABLE [dbo].[siap_m_group_user_detail]
GO

CREATE TABLE [dbo].[siap_m_group_user_detail] (
  [id] int  IDENTITY(1,1) NOT NULL,
  [group_user] varchar(255) COLLATE Latin1_General_CI_AS  NULL,
  [module_name] varchar(255) COLLATE Latin1_General_CI_AS  NULL
)
GO

ALTER TABLE [dbo].[siap_m_group_user_detail] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of siap_m_group_user_detail
-- ----------------------------
SET IDENTITY_INSERT [dbo].[siap_m_group_user_detail] ON
GO

INSERT INTO [dbo].[siap_m_group_user_detail] ([id], [group_user], [module_name]) VALUES (N'1', N'Administrator', N'dashboard')
GO

INSERT INTO [dbo].[siap_m_group_user_detail] ([id], [group_user], [module_name]) VALUES (N'2', N'Administrator', N'filter_data_ganda')
GO

INSERT INTO [dbo].[siap_m_group_user_detail] ([id], [group_user], [module_name]) VALUES (N'3', N'Administrator', N'surat_permohonan')
GO

INSERT INTO [dbo].[siap_m_group_user_detail] ([id], [group_user], [module_name]) VALUES (N'4', N'Administrator', N'unduh_template')
GO

INSERT INTO [dbo].[siap_m_group_user_detail] ([id], [group_user], [module_name]) VALUES (N'5', N'Administrator', N'unggah_permohonan')
GO

INSERT INTO [dbo].[siap_m_group_user_detail] ([id], [group_user], [module_name]) VALUES (N'6', N'Administrator', N'cek_permohonan')
GO

INSERT INTO [dbo].[siap_m_group_user_detail] ([id], [group_user], [module_name]) VALUES (N'7', N'Administrator', N'rpt_data_ganda')
GO

INSERT INTO [dbo].[siap_m_group_user_detail] ([id], [group_user], [module_name]) VALUES (N'8', N'Administrator', N'rpt_summary_data_ganda')
GO

INSERT INTO [dbo].[siap_m_group_user_detail] ([id], [group_user], [module_name]) VALUES (N'9', N'Administrator', N'rpt_detail_data_ganda')
GO

INSERT INTO [dbo].[siap_m_group_user_detail] ([id], [group_user], [module_name]) VALUES (N'10', N'PFM', N'dashboard')
GO

INSERT INTO [dbo].[siap_m_group_user_detail] ([id], [group_user], [module_name]) VALUES (N'11', N'PFM', N'filter_data_ganda')
GO

INSERT INTO [dbo].[siap_m_group_user_detail] ([id], [group_user], [module_name]) VALUES (N'12', N'PFM', N'surat_permohonan')
GO

INSERT INTO [dbo].[siap_m_group_user_detail] ([id], [group_user], [module_name]) VALUES (N'13', N'PFM', N'cek_permohonan')
GO

INSERT INTO [dbo].[siap_m_group_user_detail] ([id], [group_user], [module_name]) VALUES (N'14', N'PFM', N'rpt_data_ganda')
GO

INSERT INTO [dbo].[siap_m_group_user_detail] ([id], [group_user], [module_name]) VALUES (N'15', N'PFM', N'rpt_summary_data_ganda')
GO

INSERT INTO [dbo].[siap_m_group_user_detail] ([id], [group_user], [module_name]) VALUES (N'16', N'PFM', N'rpt_detail_data_ganda')
GO

INSERT INTO [dbo].[siap_m_group_user_detail] ([id], [group_user], [module_name]) VALUES (N'17', N'Provinsi', N'dashboard')
GO

INSERT INTO [dbo].[siap_m_group_user_detail] ([id], [group_user], [module_name]) VALUES (N'18', N'Provinsi', N'filter_data_ganda')
GO

INSERT INTO [dbo].[siap_m_group_user_detail] ([id], [group_user], [module_name]) VALUES (N'19', N'Provinsi', N'surat_permohonan')
GO

INSERT INTO [dbo].[siap_m_group_user_detail] ([id], [group_user], [module_name]) VALUES (N'20', N'Provinsi', N'unduh_template')
GO

INSERT INTO [dbo].[siap_m_group_user_detail] ([id], [group_user], [module_name]) VALUES (N'21', N'Provinsi', N'unggah_permohonan')
GO

INSERT INTO [dbo].[siap_m_group_user_detail] ([id], [group_user], [module_name]) VALUES (N'22', N'Provinsi', N'rpt_data_ganda')
GO

INSERT INTO [dbo].[siap_m_group_user_detail] ([id], [group_user], [module_name]) VALUES (N'23', N'Provinsi', N'rpt_summary_data_ganda')
GO

INSERT INTO [dbo].[siap_m_group_user_detail] ([id], [group_user], [module_name]) VALUES (N'24', N'Provinsi', N'rpt_detail_data_ganda')
GO

INSERT INTO [dbo].[siap_m_group_user_detail] ([id], [group_user], [module_name]) VALUES (N'25', N'Dinsos', N'dashboard')
GO

INSERT INTO [dbo].[siap_m_group_user_detail] ([id], [group_user], [module_name]) VALUES (N'26', N'Dinsos', N'filter_data_ganda')
GO

INSERT INTO [dbo].[siap_m_group_user_detail] ([id], [group_user], [module_name]) VALUES (N'27', N'Dinsos', N'surat_permohonan')
GO

INSERT INTO [dbo].[siap_m_group_user_detail] ([id], [group_user], [module_name]) VALUES (N'28', N'Dinsos', N'unduh_template')
GO

INSERT INTO [dbo].[siap_m_group_user_detail] ([id], [group_user], [module_name]) VALUES (N'29', N'Dinsos', N'unggah_permohonan')
GO

INSERT INTO [dbo].[siap_m_group_user_detail] ([id], [group_user], [module_name]) VALUES (N'30', N'Dinsos', N'rpt_data_ganda')
GO

INSERT INTO [dbo].[siap_m_group_user_detail] ([id], [group_user], [module_name]) VALUES (N'31', N'Dinsos', N'rpt_summary_data_ganda')
GO

INSERT INTO [dbo].[siap_m_group_user_detail] ([id], [group_user], [module_name]) VALUES (N'32', N'Dinsos', N'rpt_detail_data_ganda')
GO

INSERT INTO [dbo].[siap_m_group_user_detail] ([id], [group_user], [module_name]) VALUES (N'33', N'Korda', N'dashboard')
GO

INSERT INTO [dbo].[siap_m_group_user_detail] ([id], [group_user], [module_name]) VALUES (N'34', N'Korda', N'filter_data_ganda')
GO

INSERT INTO [dbo].[siap_m_group_user_detail] ([id], [group_user], [module_name]) VALUES (N'35', N'Korda', N'surat_permohonan')
GO

INSERT INTO [dbo].[siap_m_group_user_detail] ([id], [group_user], [module_name]) VALUES (N'36', N'Korda', N'unduh_template')
GO

INSERT INTO [dbo].[siap_m_group_user_detail] ([id], [group_user], [module_name]) VALUES (N'37', N'Korda', N'unggah_permohonan')
GO

INSERT INTO [dbo].[siap_m_group_user_detail] ([id], [group_user], [module_name]) VALUES (N'38', N'Korda', N'rpt_data_ganda')
GO

INSERT INTO [dbo].[siap_m_group_user_detail] ([id], [group_user], [module_name]) VALUES (N'39', N'Korda', N'rpt_summary_data_ganda')
GO

INSERT INTO [dbo].[siap_m_group_user_detail] ([id], [group_user], [module_name]) VALUES (N'40', N'Korda', N'rpt_detail_data_ganda')
GO

INSERT INTO [dbo].[siap_m_group_user_detail] ([id], [group_user], [module_name]) VALUES (N'41', N'Korda', N'upload_data_perbaikan')
GO

INSERT INTO [dbo].[siap_m_group_user_detail] ([id], [group_user], [module_name]) VALUES (N'42', N'Korda', N'data_ganda')
GO

INSERT INTO [dbo].[siap_m_group_user_detail] ([id], [group_user], [module_name]) VALUES (N'43', N'Administrator', N'upload_data_perbaikan')
GO

INSERT INTO [dbo].[siap_m_group_user_detail] ([id], [group_user], [module_name]) VALUES (N'44', N'Administrator', N'data_ganda')
GO

INSERT INTO [dbo].[siap_m_group_user_detail] ([id], [group_user], [module_name]) VALUES (N'45', N'PFM', N'upload_data_perbaikan')
GO

INSERT INTO [dbo].[siap_m_group_user_detail] ([id], [group_user], [module_name]) VALUES (N'46', N'PFM', N'data_ganda')
GO

INSERT INTO [dbo].[siap_m_group_user_detail] ([id], [group_user], [module_name]) VALUES (N'47', N'Provinsi', N'upload_data_perbaikan')
GO

INSERT INTO [dbo].[siap_m_group_user_detail] ([id], [group_user], [module_name]) VALUES (N'48', N'Provinsi', N'data_ganda')
GO

INSERT INTO [dbo].[siap_m_group_user_detail] ([id], [group_user], [module_name]) VALUES (N'49', N'Dinsos', N'upload_data_perbaikan')
GO

INSERT INTO [dbo].[siap_m_group_user_detail] ([id], [group_user], [module_name]) VALUES (N'50', N'Dinsos', N'data_ganda')
GO

INSERT INTO [dbo].[siap_m_group_user_detail] ([id], [group_user], [module_name]) VALUES (N'51', N'Administrator', N'filter_data_ganda_identik')
GO

INSERT INTO [dbo].[siap_m_group_user_detail] ([id], [group_user], [module_name]) VALUES (N'52', N'Dinsos', N'filter_data_ganda_identik')
GO

INSERT INTO [dbo].[siap_m_group_user_detail] ([id], [group_user], [module_name]) VALUES (N'53', N'Korda', N'filter_data_ganda_identik')
GO

INSERT INTO [dbo].[siap_m_group_user_detail] ([id], [group_user], [module_name]) VALUES (N'54', N'PFM', N'filter_data_ganda_identik')
GO

SET IDENTITY_INSERT [dbo].[siap_m_group_user_detail] OFF
GO


-- ----------------------------
-- Auto increment value for siap_m_group_user_detail
-- ----------------------------
DBCC CHECKIDENT ('[dbo].[siap_m_group_user_detail]', RESEED, 54)
GO


-- ----------------------------
-- Primary Key structure for table siap_m_group_user_detail
-- ----------------------------
ALTER TABLE [dbo].[siap_m_group_user_detail] ADD CONSTRAINT [PK__m_group___3213E83F8E5CB8F3] PRIMARY KEY CLUSTERED ([id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  
ON [PRIMARY]
GO

